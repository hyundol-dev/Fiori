sap.ui.define([
	"exam/exprogram_20/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
