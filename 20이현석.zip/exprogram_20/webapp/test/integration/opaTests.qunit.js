/* global QUnit */

sap.ui.require(["exam/exprogram20/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
